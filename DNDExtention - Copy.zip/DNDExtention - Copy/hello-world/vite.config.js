// vite.config.js

import { defineConfig } from 'vite';

export default defineConfig({
  server: {
    host: '192.168.99.66', // Replace with your IP address
    port: 5173, // Replace with your desired port
  },
});

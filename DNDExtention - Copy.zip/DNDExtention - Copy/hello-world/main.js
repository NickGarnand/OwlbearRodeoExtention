document.addEventListener('DOMContentLoaded', () => {
  const searchTypeSelect = document.getElementById('search-type');
  const searchInput = document.getElementById('search');
  const fetchDataButton = document.getElementById('fetch-data');
  const dndInfoContainer = document.getElementById('dnd-info');
  const detailedInfoContainer = document.getElementById('detailed-info');

  fetchDataButton.addEventListener('click', async () => {
    const query = searchInput.value.trim();
    const searchType = searchTypeSelect.value;
    if (!query) {
      dndInfoContainer.innerHTML = '<p>Please enter a keyword to search.</p>';
      return;
    }

    dndInfoContainer.innerHTML = '<p>Searching...</p>';
    try {
      const response = await fetch(`http://192.168.99.66:5000/api/dnd/${searchType}?query=${query}`);
      const data = await response.json();
      displayData(data, searchType);
    } catch (error) {
      console.error('Error fetching D&D data:', error);
      dndInfoContainer.innerHTML = '<p>Error fetching data. Please try again later.</p>';
    }
  });

  function displayData(data, searchType) {
    if (!data || data.length === 0) {
      dndInfoContainer.innerHTML = '<p>No results found.</p>';
      return;
    }

    const resultsHTML = data.map(item => `
      <div class="dnd-item" data-url="http://192.168.99.66:5000/api/dnd/${searchType}/${item.index}">
        <h2>${item.name}</h2>
        ${item.type ? `<p><strong>Type:</strong> ${item.type}</p>` : ''}
        ${item.challenge_rating ? `<p><strong>Challenge Rating:</strong> ${item.challenge_rating}</p>` : ''}
        ${item.alignment ? `<p><strong>Alignment:</strong> ${item.alignment}</p>` : ''}
        ${item.size ? `<p><strong>Size:</strong> ${item.size}</p>` : ''}
        ${item.hit_points ? `<p><strong>Hit Points:</strong> ${item.hit_points}</p>` : ''}
        ${item.armor_class ? `<p><strong>Armor Class:</strong> ${Array.isArray(item.armor_class) ? item.armor_class.map(ac => ac.value).join(', ') : item.armor_class}</p>` : ''}
        ${item.speed ? `<p><strong>Speed:</strong> ${item.speed}</p>` : ''}
        ${item.desc ? `<p><strong>Description:</strong> ${item.desc}</p>` : ''}
        ${item.special_abilities ? `<p><strong>Abilities:</strong> ${formatAbilities(item.special_abilities)}</p>` : ''}
      </div>
    `).join('');

    dndInfoContainer.innerHTML = resultsHTML;

    document.querySelectorAll('.dnd-item').forEach(item => {
      item.addEventListener('click', async (e) => {
        const url = e.currentTarget.dataset.url;
        await fetchDetailedData(url, searchType);
      });
    });
  }

  function formatAbilities(abilities) {
    if (!abilities) return 'None';
    return abilities.map(ability => `${ability.name}: ${ability.desc}`).join(', ');
  }

  async function fetchDetailedData(url, searchType) {
    detailedInfoContainer.innerHTML = '<p>Loading details...</p>';
    try {
      const response = await fetch(url);
      const data = await response.json();
      displayDetailedData(data, searchType);
    } catch (error) {
      console.error('Error fetching detailed D&D data:', error);
      detailedInfoContainer.innerHTML = '<p>Error fetching detailed data. Please try again later.</p>';
    }
  }

  document.addEventListener('DOMContentLoaded', async () => {
    const ip = await fetch('https://api64.ipify.org?format=json')
      .then(response => response.json())
      .then(data => data.ip);
  
    const response = await fetch('http://localhost:5000/api/log-ip', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ ip }),
    });
  
    if (response.ok) {
      console.log('IP address logged successfully');
    } else {
      console.error('Failed to log IP address');
    }
  
  
  function displayDetailedData(data, searchType) {
    let detailsHTML = `<h2>${data.name}</h2>`;

    switch (searchType) {
      case 'monsters':
        detailsHTML += `
          ${data.type ? `<p><strong>Type:</strong> ${data.type}</p>` : ''}
          ${data.challenge_rating ? `<p><strong>Challenge Rating:</strong> ${data.challenge_rating}</p>` : ''}
          ${data.alignment ? `<p><strong>Alignment:</strong> ${data.alignment}</p>` : ''}
          ${data.size ? `<p><strong>Size:</strong> ${data.size}</p>` : ''}
          ${data.hit_points ? `<p><strong>Hit Points:</strong> ${data.hit_points}</p>` : ''}
          ${data.armor_class ? `<p><strong>Armor Class:</strong> ${Array.isArray(data.armor_class) ? data.armor_class.map(ac => ac.value).join(', ') : data.armor_class}</p>` : ''}
          ${data.speed ? `<p><strong>Speed:</strong> ${data.speed}</p>` : ''}
          ${data.desc ? `<p><strong>Description:</strong> ${data.desc}</p>` : ''}
          ${data.special_abilities ? `<p><strong>Abilities:</strong> ${formatAbilities(data.special_abilities)}</p>` : ''}
          ${data.actions ? `<h3>Actions</h3> ${formatActions(data.actions)}` : ''}
        `;
        break;
      case 'spells':
        if(data.concentration == 'true')
          var concentrationVar = 'Yes'
        else
        concentrationVar = 'Yes'

        if(data.ritual == 'true')
          var ritualVar = 'Yes'
        else
        ritualVar = 'Yes'
        detailsHTML += `
          ${data.school ? `<p><strong>School:</strong> ${data.school.name}</p>` : ''}
          ${data.level ? `<p><strong>Level:</strong> ${data.level}</p>` : ''}
          ${data.casting_time ? `<p><strong>Casting Time:</strong> ${data.casting_time}</p>` : ''}
          ${data.concentration ? `<p><strong>Concentration:</strong> ${concentrationVar}</p>` : ''}
          ${data.components ? `<p><strong>Components:</strong> ${data.components.join(', ')}</p>` : ''}
          ${data.ritual ? `<p><strong>Ritual:</strong> ${ritualVar}</p>` : ''}
          ${data.duration ? `<p><strong>Duration:</strong> ${data.duration}</p>` : ''}
          ${data.range ? `<p><strong>Range:</strong> ${data.range}</p>` : ''}
          ${data.material ? `<p><strong>Material:</strong> ${data.material}</p>` : ''}
          ${data.desc ? `<p><strong>Description:</strong> ${data.desc.join(', ')}</p>` : ''}
          ${data.higher_level ? `<p><strong>Higher Level:</strong> ${data.higher_level.join(', ')}</p>` : ''}
        `;
        break;
      case 'equipment':
        detailsHTML += `
          ${data.desc ? `<p><strong>Description:</strong> ${data.desc.join(', ')}</p>` : ''}
          ${data.equipment_category ? `<p><strong>Category:</strong> ${data.equipment_category.name}</p>` : ''}
          ${data.cost ? `<p><strong>Cost:</strong> ${data.cost.quantity} ${data.cost.unit}</p>` : ''}
          ${data.weight ? `<p><strong>Weight:</strong> ${data.weight} lb</p>` : ''}
          ${data.properties ? `<p><strong>Properties:</strong> ${data.properties.map(prop => prop.name).join(', ')}</p>` : ''}
        `;
        break;
      case 'rules':
        detailsHTML += `
          ${data.desc ? `<p><strong>Description:</strong> ${data.desc.join(', ')}</p>` : ''}
        `;
        break;
      default:
        detailsHTML = '<p>No detailed information available.</p>';
    }

    detailedInfoContainer.innerHTML = detailsHTML;
  }

  function formatActions(actions) {
    if (!actions) return 'None';
    return actions.map(action => `<p><strong>${action.name}:</strong> ${action.desc}</p>`).join('');
  }
});
})

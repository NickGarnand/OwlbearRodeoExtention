from flask import Flask, jsonify, request
from flask_cors import CORS
import requests

app = Flask(__name__)
CORS(app)  # Enable CORS

BASE_URL = "https://www.dnd5eapi.co/api"

@app.route('/api/dnd/<endpoint>', methods=['GET'])
def search_dnd_data(endpoint):
    query = request.args.get('query', '').lower()
    try:
        response = requests.get(f'{BASE_URL}/{endpoint}')
        response.raise_for_status()
        data = response.json()
        results = [item for item in data['results'] if query in item['name'].lower()]
        return jsonify(results)
    except requests.exceptions.RequestException as e:
        return jsonify({'error': str(e)})

@app.route('/api/dnd/<endpoint>/<item_name>', methods=['GET'])
def get_detailed_data(endpoint, item_name):
    try:
        response = requests.get(f'{BASE_URL}/{endpoint}/{item_name}')
        response.raise_for_status()
        data = response.json()
        return jsonify(data)
    except requests.exceptions.RequestException as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
 app.run(host='0.0.0.0', port=5000, debug=True)

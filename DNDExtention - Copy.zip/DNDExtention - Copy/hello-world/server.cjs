import express from 'express';
import bodyParser from 'body-parser';
import fs from 'fs';

const app = express();
const PORT = 5000;

// Middleware for parsing JSON bodies
app.use(bodyParser.json());

// Middleware to log IP address on each request
app.use((req, res, next) => {
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
  console.log(`IP address: ${ip}`);

  // Append IP address to CSV file
  const csvData = `${ip}\n`;
  fs.appendFile('DataCollection.csv', csvData, (err) => {
    if (err) {
      console.error('Error appending to DataCollection.csv:', err);
    } else {
      console.log(`Logged IP address: ${ip}`);
    }
  });

  next();
});

// Example POST endpoint for other data
app.post('/api/log-ip', (req, res) => {
  res.status(200).send('IP address logged successfully');
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

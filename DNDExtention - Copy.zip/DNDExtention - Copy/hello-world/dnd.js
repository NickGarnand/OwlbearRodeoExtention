import axios from 'axios';

export async function fetchDndData(endpoint, name) {
  try {
    const response = await axios.get(`http://192.168.99.66:5000/api/dnd/${endpoint}/${name}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching D&D data:', error);
    return { error: 'Failed to fetch data' };
  }
}
